
# s3_utils.py

import boto3

def get_s3_client(region_name):
    return boto3.client('s3', region_name=region_name)

def upload_file_to_s3(s3_client, local_file, bucket, key):
    try:
        s3_client.upload_file(local_file, bucket, key)
        return f'Successfully uploaded {local_file} to s3://{bucket}/{key}'
    except Exception as e:
        return f'Error uploading file: {e}'
