# main.py

from config_loader import load_config
from file_checker import file_exists
from s3_utils import get_s3_client, upload_file_to_s3
from logger import setup_logger

# Constants
CONFIG_FILE_PATH = 'D:/dev/d_drive/proj_main_livegen/upload_to_s3_project/settings/config.properties'
LOG_FILE_PATH = 'D:/logs/proj_sync_webgen_s3/script_log.txt'

def main():
    # Setup logging
    logger = setup_logger(LOG_FILE_PATH)
    logger.info("Starting script execution.")

    # Load configuration
    config = load_config(CONFIG_FILE_PATH)
    region_name = config['region_name']
    local_file_path = config['local_file_path']
    bucket_name = config['bucket_name']
    s3_file_key = config['s3_file_key']

    logger.info(f"Configuration loaded: region_name={region_name}, local_file_path={local_file_path}, bucket_name={bucket_name}, s3_file_key={s3_file_key}")

    # AWS S3 Client
    s3_client = get_s3_client(region_name)

    # Check if file exists
    if file_exists(local_file_path):
        logger.info(f"File {local_file_path} exists. Starting upload.")
        result = upload_file_to_s3(s3_client, local_file_path, bucket_name, s3_file_key)
        logger.info(result)
    else:
        logger.error(f"File {local_file_path} does not exist.")

    logger.info("Script execution completed.")

if __name__ == '__main__':
    main()
